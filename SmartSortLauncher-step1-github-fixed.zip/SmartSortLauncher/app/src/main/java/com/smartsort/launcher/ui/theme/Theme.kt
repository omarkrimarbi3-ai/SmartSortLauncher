package com.smartsort.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onSurface = Color(0xFFF2F4F8),
    surface = Color(0xFF12141A),
)
private val Light = lightColorScheme(
    primary = Color(0xFF2F5BEA),
    onSurface = Color(0xFF14171F),
    surface = Color(0xFFF7F8FB),
)

@Composable
fun SmartSortTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
