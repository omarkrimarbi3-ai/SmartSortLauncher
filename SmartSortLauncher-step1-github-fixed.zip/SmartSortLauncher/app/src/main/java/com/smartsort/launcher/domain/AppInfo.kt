package com.smartsort.launcher.domain

import android.content.ComponentName
import android.os.UserHandle
import androidx.compose.ui.graphics.ImageBitmap

/** نموذج التطبيق المستخدم في كل الشاشات. */
data class AppInfo(
    val packageName: String,
    val className: String,
    val label: String,
    val icon: ImageBitmap,
    val installTime: Long,
    val user: UserHandle,
) {
    /** مفتاح فريد (قد يتكرر نفس الـ package لملفات عمل مختلفة). */
    val key: String get() = "$packageName/$className/${user.hashCode()}"
    val component: ComponentName get() = ComponentName(packageName, className)
}
